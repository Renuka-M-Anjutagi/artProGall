

import React from 'react'
import Category from '../../pages/Category'

const Menu = () => {
  return (
    <Category />
  )
}

export default Menu