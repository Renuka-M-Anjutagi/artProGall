import React from 'react'
import DashboradPage from '../../components/layout/DashboradPage'

const Dashborad = () => {
  return (
    <div>
      <DashboradPage/>
    </div>
  )
}

export default Dashborad
