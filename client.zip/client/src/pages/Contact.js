import React from "react";
import Layout from '../components/layout/Layout'

import ContactPage from "../components/layout/ContactPage";
const Contact = () => {
  return (
      <ContactPage />
  )
};


export default Contact